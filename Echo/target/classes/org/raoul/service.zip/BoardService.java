package org.raoul.service;

import org.raoul.domain.BoardVO;

public interface BoardService extends CRUDGenericService<BoardVO, Integer> {

}
