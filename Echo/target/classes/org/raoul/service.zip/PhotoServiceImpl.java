package org.raoul.service;

import java.util.List;

import org.raoul.domain.PhotoVO;
import org.springframework.stereotype.Service;

@Service
public class PhotoServiceImpl implements PhotoService {

	@Override
	public void add(PhotoVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PhotoVO read(Integer key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int modify(PhotoVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int remove(Integer key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<PhotoVO> getList() {
		// TODO Auto-generated method stub
		return null;
	}

}
