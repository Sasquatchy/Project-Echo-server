package org.raoul.domain;

import lombok.Data;

@Data
public class AuthVO {

	private Integer authno;
	private String uid, auth;
}
