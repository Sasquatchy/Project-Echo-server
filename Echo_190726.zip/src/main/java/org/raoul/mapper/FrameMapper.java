package org.raoul.mapper;

public interface FrameMapper {

}
