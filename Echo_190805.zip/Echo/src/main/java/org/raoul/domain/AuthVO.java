package org.raoul.domain;

import lombok.Data;

@Data
public class AuthVO {

	private String uid, auth;
}
