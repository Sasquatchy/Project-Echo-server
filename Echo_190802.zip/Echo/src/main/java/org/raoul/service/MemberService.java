package org.raoul.service;

import org.raoul.domain.MemberVO;

public interface MemberService extends CRUDGenericService<MemberVO, Integer> {

}
