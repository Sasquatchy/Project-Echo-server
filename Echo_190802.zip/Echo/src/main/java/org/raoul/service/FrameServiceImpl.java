package org.raoul.service;

import java.util.List;

import org.raoul.domain.Criteria;
import org.raoul.domain.FrameVO;
import org.springframework.stereotype.Service;

@Service
public class FrameServiceImpl implements FrameService {

	@Override
	public void add(FrameVO vo) {
		// TODO Auto-generated method stub

	}

	@Override
	public FrameVO read(Integer key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int modify(FrameVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int remove(Integer key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<FrameVO> getList(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

}
