package org.raoul.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.raoul.domain.PhotoDTO;
import org.raoul.mapper.PhotoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.log4j.Log4j;
import net.coobird.thumbnailator.Thumbnailator;

@Log4j
@Service
public class PhotoServiceImpl implements PhotoService {

	@Autowired
	PhotoMapper pMapper;

	@Transactional
	@Override
	public List<PhotoDTO> upload(MultipartFile[] uploadFiles, String rootPath, String memberUid, Integer BoardNumber) {

		String dateFolder= getFolder();
		String parentPath = rootPath + File.separator +memberUid + File.separator + dateFolder;

		String thumbnailPath = parentPath + File.separator +"thumbnail";
		File parentFolder = new File(parentPath);
		log.info("parentPath :" + parentPath);

		// check if folder not exist
		if (parentFolder.exists() == false) {
			log.info("make directories");
			parentFolder.mkdirs();
			File thumbFolder = new File(thumbnailPath);
			thumbFolder.mkdir();
		}

		List<PhotoDTO> listOfPhoto = new ArrayList<>();

		for (MultipartFile multipartFile : uploadFiles) {
			UUID uuid = UUID.randomUUID();

			String thumbFileName = "thumb_" + uuid.toString() + multipartFile.getOriginalFilename();
			log.info("thumbFileName:" + thumbFileName);

			String sourceFileName = uuid.toString() + multipartFile.getOriginalFilename();
			log.info("sourceFileName:" + sourceFileName);

			// save thumbnail
			try {
				saveResizeFile(multipartFile, thumbnailPath, thumbFileName, 400, 240);
				// save photo
				PhotoDTO dto = saveResizeFile(multipartFile, parentPath, sourceFileName, 800, 480);
				
				// set photo's info
				setDestPhotoDTO(dto,BoardNumber, memberUid);
				
				// log photo's final form
				log.info(dto);
				
				// insert DB
				pMapper.insert(dto);
				
				// add on the list of dto from this operation
				listOfPhoto.add(dto);
			} catch (Exception e) {
				e.printStackTrace();
				//if error occurs, delete files.
				for(PhotoDTO dto : listOfPhoto) {
					
					Path thumbFilePath = Paths.get(dto.getFolderPath(), "thumbnail","thumb_"+dto.getPhotoname());
					Path filePath = Paths.get(dto.getFolderPath(), dto.getPhotoname());
					
					try {
						Files.deleteIfExists(thumbFilePath);
						Files.deleteIfExists(filePath);
					} catch (IOException e1) {
						log.error(e1);
					}
				}
				return null;
			}
		}
		return listOfPhoto;
	}

	
	
	public PhotoDTO read(Integer pno) {
		return pMapper.select(pno);
	}

	public int remove(Integer pno) {
		// TODO Auto-generated method stub
		PhotoDTO targetDto = pMapper.select(pno);
		String targetFolderPath = targetDto.getFolderPath();
		String targetPhotoname = targetDto.getPhotoname();
		log.info("deleting file " + targetPhotoname + " in " + targetFolderPath);
		int count = pMapper.delete(pno);
		// delete dto first, then delete server file.
		log.info(targetFolderPath + File.separator + targetPhotoname);
		Path targetPath= Paths.get(targetFolderPath, targetPhotoname);
		Path targetThumbPath = Paths.get(targetFolderPath,"thumbnail","thumb_"+targetPhotoname);
		try {
			Files.deleteIfExists(targetPath);
			Files.deleteIfExists(targetThumbPath);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return count;
	}

	public void removeAllFromBoard(Integer bno) {
		PhotoDTO targetDTO = getListByBoard(bno).get(0);
		log.info("clearing files in folder " + targetDTO.getFolderPath());
		File parentFolder = new File(targetDTO.getFolderPath());
		try {
			FileUtils.cleanDirectory(parentFolder);
		} catch (IOException e) {
			e.printStackTrace();
		}
		parentFolder.delete();

	}

	public List<PhotoDTO> getListByBoard(Integer bno) {
		return pMapper.findListByBoard(bno);
	}

	public List<PhotoDTO> getListByMember(String uid) {
		return pMapper.findListByMember(uid);
	}

	private PhotoDTO setDestPhotoDTO(PhotoDTO dto, Integer bno, String uid) {

		dto.setBno(bno);
		dto.setUid(uid);
		return dto;
	}

	// resize and save the file with given parameter
	private PhotoDTO saveResizeFile(MultipartFile uploadFile, String folderPath, String fileName, int width, int height)
			throws Exception {

		File file = new File(folderPath, fileName);
		log.info("fileName:" + fileName);
		FileOutputStream os = new FileOutputStream(file);
		log.info("os:" + os);
		Thumbnailator.createThumbnail(uploadFile.getInputStream(), os, width, height);
		os.close();

		return new PhotoDTO(null, fileName, folderPath, null, null, null);
	}

	// method that make a name of folder yy/mm/dd
	private String getFolder() {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date date = new Date();

		String str = sdf.format(date);

		return str.replace("-", File.separator);
	}

	// check file type
	@SuppressWarnings("unused")
	private boolean checkImageType(File file) {

		try {
			String contentType = Files.probeContentType(file.toPath());

			return contentType.startsWith("image");
		} catch (IOException e) {
			log.error(e);
		}
		return false;
	}

}
