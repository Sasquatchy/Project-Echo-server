package org.raoul.service;

import org.raoul.domain.FrameVO;

public interface FrameService extends CRUDGenericService<FrameVO, Integer> {

}
