package org.raoul.mapper;

public class MemberMapperTests implements GenericMapperTests{

	MemberMapper mapper;
	
	@Override
	public void addTest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void readTest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateTest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteTest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getListTest() {
		// TODO Auto-generated method stub
		
	}

}
